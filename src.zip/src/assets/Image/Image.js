import logo from './Logo.png'
import GoldLogo from './Gold_Logo.png'



import saloon from './saloon.png'
import Sandya from './mrssandya.jpeg'
import head_x1 from './head_x1.jpg'
import head_x2 from './head_x2.jpg'
import head_x3 from './head_x3.jpg'
import b1  from './b1.png'
import b2  from './b2.jpg'
import b3  from './b3.jpg'
import b4  from './b4.jpg'
import b5  from './b5.jpg'
import facebook from './facebook.png'
import instagram from './instagram.png'
import youtube from'./youtube.png' 
import tiktok from './tiktok.png'
import map_icon from './map-icon.png'
import phone_icon from './phone-icon.png'
import email_icon from './email.png'






import blockquote from './blockquote.svg'
import d1 from './d1.png'
import d2 from './d2.png'
import d3 from './d3.png'
import d4 from './d4.png'
import d5 from './d5.png'
import d6 from './d6.png'
import d7 from './d7.png'
import d8 from './d8.png'
import e1 from './e1.jpg'
import e2 from './e2.jpg'
import e3 from './e3.jpg'
import e4 from './e4.jpg'
import e5 from './e5.jpg'
import e6 from './e6.jpg'
import e7 from './e7.jpg'
import e8 from './e8.jpg'

import priyantha from './priyantha.jpg'
import sandya from './sandya.jpg'
import g1 from './g1.jpg'
import g2 from './g2.jpg'
import h1 from './h1.jpg'
import h2 from './h2.jpg'
import h3 from './h3.jpg'
import h4 from './h4.jpg'
import i1 from './i1.png'
import i2 from './i2.png'
import i3 from './i3.png'
import i4 from './i4.png'
import i5 from './i5.png'
import j1 from './j1.jpg'
import j2 from './j2.jpg'
import j3 from './j3.jpg'
import j4 from './j5.jpg'
import j5 from './j6.jpg'
import j6 from './j8.jpg'
import j7 from './j4.jpg'
import j9 from './j9.jpg'
import priyanthab from './priyanthab.jpg'
import sandyab from './sandyab.jpg'
import Wax from './Wax.jpg'






import Logo_icon from './map-icon.png'
import rev_madu from './rew-madu.png'
import rev_senuri from './rev-senuri.png'
import k1 from './k1.jpg'
import k2 from './k2.jpg'
import k3 from './k3.jpg'
import k4 from './k4.jpg'

const Image = {
  logo,
  GoldLogo,
sandyab,


  Sandya,
  saloon,
  head_x1,
  head_x2,
  head_x3,
  b1,
  b2,
  b3,
  b4,
  b5,
  facebook,
  instagram,
  youtube,
  tiktok,
  email_icon,
  map_icon,
  phone_icon,

 

  blockquote,
  d1,
  d2,
  d3,
  d4,
  d5,
  d6,
  d7,
  d8,
  e1,
  e2,
  e3,
  e4,
  e5,
  e6,
  e7,
  e8,

  priyantha,
  sandya,
  g1,
  g2,
  h1,
  h2,
  h3,
  h4,
  i1,
  i2,
  i3,
  i4,
  i5,
  j1,
  j2,
  j3,
  j4,
  j5,
  j6,
  j7,
  j9,
  Wax,
  Logo_icon,
  rev_madu,
  rev_senuri,
  k1,
  k2,
  k3,
  k4,
  priyanthab
}

export default Image
